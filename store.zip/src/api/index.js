export { getProduct } from "./getProduct.js";
export { getProducts } from "./getProducts.js";
export { default as axiosClient } from "./axiosClient.js";
